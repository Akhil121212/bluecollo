
import { useState } from "react";
import { useLanguage } from "@/components/LanguageProvider";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Briefcase, MapPin, Clock, Search } from "lucide-react";

type Job = {
  id: number;
  title: string;
  company: string;
  location: string;
  type: string;
  posted: string;
  description: string;
};

export default function Jobs() {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock job data
  const jobs: Job[] = [
    {
      id: 1,
      title: "Construction Worker",
      company: "BuildRight Construction",
      location: "New Delhi, India",
      type: "Full-time",
      posted: "2 days ago",
      description: "We are looking for experienced construction workers for a commercial building project."
    },
    {
      id: 2,
      title: "Plumber",
      company: "PlumbPerfect Services",
      location: "Mumbai, India",
      type: "Contract",
      posted: "1 week ago",
      description: "Residential plumbing services for a new apartment complex."
    },
    {
      id: 3,
      title: "Electrician",
      company: "PowerWire Solutions",
      location: "Bangalore, India",
      type: "Part-time",
      posted: "3 days ago",
      description: "Industrial wiring and maintenance position available."
    },
    {
      id: 4,
      title: "Carpenter",
      company: "WoodCraft Furnishings",
      location: "Chennai, India",
      type: "Full-time",
      posted: "Just now",
      description: "Custom furniture creation and installation for high-end clients."
    }
  ];
  
  const filteredJobs = jobs.filter(job => 
    job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    job.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <div className="container py-10 md:py-16 px-4">
          <div className="max-w-5xl mx-auto">
            <div className="flex flex-col gap-8 animate-fade-in">
              <div className="text-center">
                <div className="inline-block bg-primary/10 p-3 rounded-full mb-4">
                  <Briefcase className="h-8 w-8 text-primary" />
                </div>
                <h1 className="text-3xl md:text-4xl font-bold mb-3">{t("jobs.title")}</h1>
                <p className="text-muted-foreground max-w-lg mx-auto">
                  {t("jobs.subtitle")}
                </p>
              </div>
              
              {/* Search bar */}
              <div className="relative animate-slide-up mb-4" style={{ animationDelay: "200ms" }}>
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                <Input
                  className="pl-10 bg-background hover-scale"
                  placeholder={t("jobs.search")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              {/* Job listings */}
              <div className="grid grid-cols-1 gap-6">
                {filteredJobs.map((job, index) => (
                  <div 
                    key={job.id}
                    className="border rounded-lg p-6 hover:shadow-md transition-all duration-200 animate-slide-up hover-scale bg-background"
                    style={{ animationDelay: `${300 + index * 100}ms` }}
                  >
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div>
                        <h3 className="text-xl font-medium">{job.title}</h3>
                        <p className="text-muted-foreground">{job.company}</p>
                        <div className="flex flex-wrap gap-4 mt-2">
                          <span className="flex items-center text-sm text-muted-foreground">
                            <MapPin className="mr-1 h-4 w-4" />
                            {job.location}
                          </span>
                          <span className="flex items-center text-sm text-muted-foreground">
                            <Briefcase className="mr-1 h-4 w-4" />
                            {job.type}
                          </span>
                          <span className="flex items-center text-sm text-muted-foreground">
                            <Clock className="mr-1 h-4 w-4" />
                            {job.posted}
                          </span>
                        </div>
                        <p className="mt-2">{job.description}</p>
                      </div>
                      <div className="flex-shrink-0">
                        <Button className="min-w-32 hover-scale">
                          {t("jobs.apply")}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                
                {filteredJobs.length === 0 && (
                  <div className="text-center p-10 border rounded-lg">
                    <p className="text-muted-foreground">
                      {t("jobs.no_results")}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
