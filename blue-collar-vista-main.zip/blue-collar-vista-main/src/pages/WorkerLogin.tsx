
import { useState } from "react";
import { useLanguage } from "@/components/LanguageProvider";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { WorkerDetailsForm } from "@/components/WorkerDetailsForm";
import { Briefcase, UserRound } from "lucide-react";

export default function WorkerLogin() {
  const { t } = useLanguage();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <div className="container py-10 md:py-16 px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col gap-8 animate-fade-in">
              <div className="text-center">
                <div className="inline-block bg-primary/10 p-3 rounded-full mb-4">
                  <UserRound className="h-8 w-8 text-primary" />
                </div>
                <h1 className="text-3xl md:text-4xl font-bold mb-3">{t("worker.login.title")}</h1>
                <p className="text-muted-foreground max-w-md mx-auto">
                  {t("worker.login.subtitle")}
                </p>
              </div>
              
              <div className="glass-card animate-scale-in">
                <WorkerDetailsForm />
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
