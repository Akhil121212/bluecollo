
import { useState } from "react";
import { useLanguage } from "@/components/LanguageProvider";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { User, MapPin, Star, Search } from "lucide-react";

type Worker = {
  id: number;
  name: string;
  location: string;
  skills: string[];
  rating: number;
  jobsCompleted: number;
  available: boolean;
};

export default function Workers() {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Mock worker data
  const workers: Worker[] = [
    {
      id: 1,
      name: "Rajesh Kumar",
      location: "New Delhi, India",
      skills: ["Plumbing", "Electrical", "Carpentry"],
      rating: 4.8,
      jobsCompleted: 87,
      available: true
    },
    {
      id: 2,
      name: "Priya Sharma",
      location: "Mumbai, India",
      skills: ["Painting", "Cleaning", "Home Repair"],
      rating: 4.6,
      jobsCompleted: 53,
      available: true
    },
    {
      id: 3,
      name: "Amir Khan",
      location: "Bangalore, India",
      skills: ["Construction", "Masonry", "Welding"],
      rating: 4.9,
      jobsCompleted: 124,
      available: false
    },
    {
      id: 4,
      name: "Kavita Patel",
      location: "Hyderabad, India",
      skills: ["Gardening", "Landscaping", "Irrigation"],
      rating: 4.7,
      jobsCompleted: 42,
      available: true
    }
  ];
  
  const filteredWorkers = workers.filter(worker => 
    worker.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    worker.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    worker.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <div className="container py-10 md:py-16 px-4">
          <div className="max-w-5xl mx-auto">
            <div className="flex flex-col gap-8 animate-fade-in">
              <div className="text-center">
                <div className="inline-block bg-primary/10 p-3 rounded-full mb-4">
                  <User className="h-8 w-8 text-primary" />
                </div>
                <h1 className="text-3xl md:text-4xl font-bold mb-3">{t("workers.title")}</h1>
                <p className="text-muted-foreground max-w-lg mx-auto">
                  {t("workers.subtitle")}
                </p>
              </div>
              
              {/* Search bar */}
              <div className="relative animate-slide-up mb-4" style={{ animationDelay: "200ms" }}>
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                <Input
                  className="pl-10 bg-background hover-scale"
                  placeholder={t("workers.search")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              {/* Worker listings */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredWorkers.map((worker, index) => (
                  <div 
                    key={worker.id}
                    className="border rounded-lg p-6 hover:shadow-md transition-all duration-200 animate-slide-up hover-scale bg-background"
                    style={{ animationDelay: `${300 + index * 100}ms` }}
                  >
                    <div className="flex items-start gap-4">
                      <div className="bg-primary/10 p-3 rounded-full">
                        <User className="h-8 w-8 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <h3 className="text-xl font-medium">{worker.name}</h3>
                          <Badge variant={worker.available ? "default" : "secondary"}>
                            {worker.available ? t("workers.available") : t("workers.unavailable")}
                          </Badge>
                        </div>
                        <p className="flex items-center text-sm text-muted-foreground mt-1">
                          <MapPin className="mr-1 h-4 w-4" /> {worker.location}
                        </p>
                        
                        <div className="flex items-center mt-2">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                            <span className="ml-1 font-medium">{worker.rating}</span>
                          </div>
                          <span className="mx-2 text-muted-foreground">•</span>
                          <span className="text-sm text-muted-foreground">
                            {worker.jobsCompleted} {t("workers.jobs_completed")}
                          </span>
                        </div>
                        
                        <div className="mt-3 flex flex-wrap gap-2">
                          {worker.skills.map((skill) => (
                            <Badge key={skill} variant="outline">{skill}</Badge>
                          ))}
                        </div>
                        
                        <div className="mt-4">
                          <Button className="w-full hover-scale">
                            {t("workers.view_profile")}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {filteredWorkers.length === 0 && (
                  <div className="text-center p-10 border rounded-lg md:col-span-2">
                    <p className="text-muted-foreground">
                      {t("workers.no_results")}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
