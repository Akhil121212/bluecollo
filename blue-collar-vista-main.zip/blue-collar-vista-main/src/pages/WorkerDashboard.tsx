
import { useState } from "react";
import { useLanguage } from "@/components/LanguageProvider";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, MessageCircle, Video } from "lucide-react";
import { DirectChat } from "@/components/DirectChat";

export default function WorkerDashboard() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState("overview");
  
  const workerInfo = {
    name: "John Doe",
    status: "Active",
    jobsCompleted: 24,
    rating: 4.8,
    earnings: "$1,240",
  };
  
  const upcomingJobs = [
    { id: 1, title: "Kitchen Renovation", location: "123 Main St", date: "2025-05-20", time: "09:00 AM" },
    { id: 2, title: "Bathroom Plumbing", location: "456 Elm St", date: "2025-05-22", time: "10:30 AM" },
    { id: 3, title: "Roof Repair", location: "789 Oak Ave", date: "2025-05-25", time: "01:00 PM" },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <div className="container py-10 md:py-16 px-4">
          <div className="max-w-5xl mx-auto">
            <div className="flex flex-col gap-8 animate-fade-in">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold mb-2">{t("dashboard.welcome")}, {workerInfo.name}!</h1>
                  <p className="text-muted-foreground">
                    {t("dashboard.currentStatus")}: <span className="text-green-500 font-medium">{workerInfo.status}</span>
                  </p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="animate-slide-up hover-scale" style={{ animationDelay: "100ms" }}>
                  <CardHeader className="pb-2">
                    <CardDescription>{t("dashboard.jobsCompleted")}</CardDescription>
                    <CardTitle className="text-3xl font-bold">{workerInfo.jobsCompleted}</CardTitle>
                  </CardHeader>
                </Card>
                <Card className="animate-slide-up hover-scale" style={{ animationDelay: "200ms" }}>
                  <CardHeader className="pb-2">
                    <CardDescription>{t("dashboard.rating")}</CardDescription>
                    <CardTitle className="text-3xl font-bold">{workerInfo.rating}/5.0</CardTitle>
                  </CardHeader>
                </Card>
                <Card className="animate-slide-up hover-scale" style={{ animationDelay: "300ms" }}>
                  <CardHeader className="pb-2">
                    <CardDescription>{t("dashboard.earnings")}</CardDescription>
                    <CardTitle className="text-3xl font-bold">{workerInfo.earnings}</CardTitle>
                  </CardHeader>
                </Card>
              </div>
              
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-2 md:grid-cols-3 mb-6">
                  <TabsTrigger value="overview" className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4" />
                    {t("dashboard.jobs")}
                  </TabsTrigger>
                  <TabsTrigger value="videos" className="flex items-center gap-2">
                    <Video className="h-4 w-4" />
                    {t("dashboard.videos")}
                  </TabsTrigger>
                  <TabsTrigger value="chat" className="flex items-center gap-2">
                    <MessageCircle className="h-4 w-4" />
                    {t("dashboard.chat")}
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="overview">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("dashboard.upcomingJobs")}</CardTitle>
                      <CardDescription>{t("dashboard.upcomingJobsDescription")}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {upcomingJobs.length > 0 ? (
                        <div className="space-y-4">
                          {upcomingJobs.map((job) => (
                            <div 
                              key={job.id} 
                              className="border rounded-lg p-4 hover:bg-accent/10 transition-colors"
                            >
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-medium">{job.title}</h3>
                                  <p className="text-sm text-muted-foreground">{job.location}</p>
                                </div>
                                <div className="text-right text-sm">
                                  <p>{new Date(job.date).toLocaleDateString()}</p>
                                  <p className="text-muted-foreground">{job.time}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-6 text-muted-foreground">
                          {t("dashboard.noUpcomingJobs")}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="videos">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("dashboard.videoSkills")}</CardTitle>
                      <CardDescription>{t("dashboard.videoSkillsDescription")}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        {/* Just a placeholder - in a real app, these would come from the database */}
                        <div className="border rounded-lg overflow-hidden hover-scale">
                          <div className="bg-secondary aspect-video flex items-center justify-center">
                            <Video className="h-10 w-10 text-muted-foreground" />
                          </div>
                          <div className="p-3">
                            <h4 className="font-medium">{t("dashboard.skillVideo1")}</h4>
                            <p className="text-xs text-muted-foreground mt-1">Added on May 10, 2025</p>
                          </div>
                        </div>
                        <div className="border rounded-lg overflow-hidden hover-scale">
                          <div className="bg-secondary aspect-video flex items-center justify-center">
                            <Video className="h-10 w-10 text-muted-foreground" />
                          </div>
                          <div className="p-3">
                            <h4 className="font-medium">{t("dashboard.skillVideo2")}</h4>
                            <p className="text-xs text-muted-foreground mt-1">Added on May 12, 2025</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="chat">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("dashboard.directMessages")}</CardTitle>
                      <CardDescription>{t("dashboard.directMessagesDescription")}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <DirectChat />
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
