
import React, { createContext, useState, useContext, ReactNode } from "react";

type Language = "en" | "es" | "hi" | "te" | "kn";

interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const translations: Translations = {
  en: {
    "site.title": "BlueCollar",
    "site.description": "Find blue-collar jobs and workers in your area",
    
    "nav.home": "Home",
    "nav.jobs": "Jobs",
    "nav.workers": "Workers",
    "nav.how-it-works": "How It Works",
    "nav.login": "Login",
    "nav.register": "Register",
    
    "hero.title": "Find the right job or the right worker",
    "hero.subtitle": "Connecting skilled blue-collar workers with employers looking for talent",
    "hero.cta": "Get Started",
    "hero.cta.workers": "I'm looking for work",
    "hero.cta.employers": "I need to hire",

    "features.title": "How It Works",
    "features.register.title": "Create Profile",
    "features.register.description": "Sign up and complete your profile with skills and experience",
    "features.search.title": "Find Opportunities",
    "features.search.description": "Search for jobs matching your skills and location",
    "features.apply.title": "Apply & Connect",
    "features.apply.description": "Apply for jobs and connect directly with employers",

    "jobs.featured": "Featured Jobs",
    "jobs.viewall": "View All Jobs",
    "jobs.location": "Location",
    "jobs.posted": "Posted",
    "jobs.apply": "Apply Now",
    
    // Worker login and form translations
    "worker.login.title": "Worker Registration",
    "worker.login.subtitle": "Create your profile to find jobs matching your skills and location",
    "worker.login.success": "Profile created successfully!",
    
    "worker.form.name": "Full Name",
    "worker.form.namePlaceholder": "Enter your full name",
    "worker.form.phone": "Phone Number",
    "worker.form.phonePlaceholder": "Enter your phone number",
    "worker.form.email": "Email Address",
    "worker.form.emailPlaceholder": "Enter your email address",
    "worker.form.skills": "Skills",
    "worker.form.skillsPlaceholder": "e.g. Plumbing, Electrical, Carpentry",
    "worker.form.experience": "Work Experience",
    "worker.form.experiencePlaceholder": "Describe your previous work experience, certifications, and skills",
    "worker.form.location": "Location",
    "worker.form.locationPlaceholder": "Your city or area",
    "worker.form.workRadius": "Work Radius (km)",
    "worker.form.acceptTerms": "I accept the terms and conditions",
    "worker.form.submit": "Create Profile",
    "worker.form.submitting": "Creating...",
    
    "footer.rights": "All rights reserved",
    "footer.privacy": "Privacy Policy",
    "footer.terms": "Terms of Service",
    "footer.contact": "Contact Us",
  },
  es: {
    "site.title": "BlueCollar",
    "site.description": "Encuentra trabajos y trabajadores de cuello azul en tu área",
    
    "nav.home": "Inicio",
    "nav.jobs": "Trabajos",
    "nav.workers": "Trabajadores",
    "nav.how-it-works": "Cómo Funciona",
    "nav.login": "Iniciar Sesión",
    "nav.register": "Registrarse",
    
    "hero.title": "Encuentra el trabajo adecuado o el trabajador adecuado",
    "hero.subtitle": "Conectando trabajadores cualificados de cuello azul con empleadores en búsqueda de talento",
    "hero.cta": "Comenzar",
    "hero.cta.workers": "Busco trabajo",
    "hero.cta.employers": "Necesito contratar",

    "features.title": "Cómo Funciona",
    "features.register.title": "Crear Perfil",
    "features.register.description": "Regístrate y completa tu perfil con habilidades y experiencia",
    "features.search.title": "Encontrar Oportunidades",
    "features.search.description": "Busca trabajos que coincidan con tus habilidades y ubicación",
    "features.apply.title": "Aplicar y Conectar",
    "features.apply.description": "Aplica a trabajos y conecta directamente con empleadores",

    "jobs.featured": "Trabajos Destacados",
    "jobs.viewall": "Ver Todos los Trabajos",
    "jobs.location": "Ubicación",
    "jobs.posted": "Publicado",
    "jobs.apply": "Aplicar Ahora",
    
    // Worker login and form translations in Spanish
    "worker.login.title": "Registro de Trabajador",
    "worker.login.subtitle": "Crea tu perfil para encontrar trabajos que coincidan con tus habilidades y ubicación",
    "worker.login.success": "¡Perfil creado exitosamente!",
    
    "worker.form.name": "Nombre Completo",
    "worker.form.namePlaceholder": "Ingresa tu nombre completo",
    "worker.form.phone": "Número de Teléfono",
    "worker.form.phonePlaceholder": "Ingresa tu número de teléfono",
    "worker.form.email": "Correo Electrónico",
    "worker.form.emailPlaceholder": "Ingresa tu correo electrónico",
    "worker.form.skills": "Habilidades",
    "worker.form.skillsPlaceholder": "ej. Plomería, Electricidad, Carpintería",
    "worker.form.experience": "Experiencia Laboral",
    "worker.form.experiencePlaceholder": "Describe tu experiencia laboral previa, certificaciones y habilidades",
    "worker.form.location": "Ubicación",
    "worker.form.locationPlaceholder": "Tu ciudad o área",
    "worker.form.workRadius": "Radio de Trabajo (km)",
    "worker.form.acceptTerms": "Acepto los términos y condiciones",
    "worker.form.submit": "Crear Perfil",
    "worker.form.submitting": "Creando...",
    
    "footer.rights": "Todos los derechos reservados",
    "footer.privacy": "Política de Privacidad",
    "footer.terms": "Términos de Servicio",
    "footer.contact": "Contáctenos",
  },
  hi: {
    "site.title": "ब्लूकॉलर",
    "site.description": "अपने क्षेत्र में ब्लू-कॉलर नौकरियां और श्रमिक खोजें",
    
    "nav.home": "होम",
    "nav.jobs": "नौकरियां",
    "nav.workers": "श्रमिक",
    "nav.how-it-works": "यह कैसे काम करता है",
    "nav.login": "लॉगिन",
    "nav.register": "रजिस्टर करें",
    
    "hero.title": "सही नौकरी या सही श्रमिक खोजें",
    "hero.subtitle": "कुशल ब्लू-कॉलर श्रमिकों को प्रतिभा की तलाश में नियोक्ताओं से जोड़ना",
    "hero.cta": "शुरू करें",
    "hero.cta.workers": "मैं काम ढूंढ रहा हूं",
    "hero.cta.employers": "मुझे किराया करने की जरूरत है",

    "features.title": "यह कैसे काम करता है",
    "features.register.title": "प्रोफाइल बनाएं",
    "features.register.description": "साइन अप करें और कौशल और अनुभव के साथ अपनी प्रोफ़ाइल पूरी करें",
    "features.search.title": "अवसर खोजें",
    "features.search.description": "अपने कौशल और स्थान से मेल खाती नौकरियों की खोज करें",
    "features.apply.title": "आवेदन करें और जुड़ें",
    "features.apply.description": "नौकरियों के लिए आवेदन करें और नियोक्ताओं से सीधे जुड़ें",

    "jobs.featured": "विशेष नौकरियां",
    "jobs.viewall": "सभी नौकरियां देखें",
    "jobs.location": "स्थान",
    "jobs.posted": "पोस्ट किया गया",
    "jobs.apply": "अभी आवेदन करें",
    
    // Worker login and form translations in Hindi
    "worker.login.title": "श्रमिक पंजीकरण",
    "worker.login.subtitle": "अपने कौशल और स्थान से मेल खाती नौकरियां खोजने के लिए अपनी प्रोफ़ाइल बनाएं",
    "worker.login.success": "प्रोफ़ाइल सफलतापूर्वक बनाई गई!",
    
    "worker.form.name": "पूरा नाम",
    "worker.form.namePlaceholder": "अपना पूरा नाम दर्ज करें",
    "worker.form.phone": "फ़ोन नंबर",
    "worker.form.phonePlaceholder": "अपना फ़ोन नंबर दर्ज करें",
    "worker.form.email": "ईमेल पता",
    "worker.form.emailPlaceholder": "अपना ईमेल पता दर्ज करें",
    "worker.form.skills": "कौशल",
    "worker.form.skillsPlaceholder": "जैसे प्लंबिंग, इलेक्ट्रिकल, बढ़ईगीरी",
    "worker.form.experience": "कार्य अनुभव",
    "worker.form.experiencePlaceholder": "अपने पिछले कार्य अनुभव, प्रमाणपत्र और कौशल का वर्णन करें",
    "worker.form.location": "स्थान",
    "worker.form.locationPlaceholder": "आपका शहर या क्षेत्र",
    "worker.form.workRadius": "कार्य त्रिज्या (किमी)",
    "worker.form.acceptTerms": "मैं नियमों और शर्तों को स्वीकार करता हूं",
    "worker.form.submit": "प्रोफ़ाइल बनाएं",
    "worker.form.submitting": "बना रहे हैं...",
    
    "footer.rights": "सभी अधिकार सुरक्षित",
    "footer.privacy": "गोपनीयता नीति",
    "footer.terms": "सेवा की शर्तें",
    "footer.contact": "संपर्क करें",
  },
  te: {
    "site.title": "బ్లూకాలర్",
    "site.description": "మీ ప్రాంతంలో బ్లూ-కాలర్ ఉద్యోగాలు మరియు కార్మికులను కనుగొనండి",
    
    "nav.home": "హోమ్",
    "nav.jobs": "ఉద్యోగాలు",
    "nav.workers": "కార్మికులు",
    "nav.how-it-works": "ఇది ఎలా పనిచేస్తుంది",
    "nav.login": "లాగిన్",
    "nav.register": "నమోదు చేసుకోండి",
    
    "hero.title": "సరైన ఉద్యోగాన్ని లేదా సరైన కార్మికుడిని కనుగొనండి",
    "hero.subtitle": "నైపుణ్యం గల బ్లూ-కాలర్ కార్మికులను ప్రతిభను అన్వేషించే యజమానులతో కలపడం",
    "hero.cta": "ప్రారంభించండి",
    "hero.cta.workers": "నాకు పని కావాలి",
    "hero.cta.employers": "నాకు నియామకం చేయాలి",

    "features.title": "ఇది ఎలా పనిచేస్తుంది",
    "features.register.title": "ప్రొఫైల్ సృష్టించండి",
    "features.register.description": "సైన్ అప్ చేసి మీ ప్రొఫైల్‌ని నైపుణ్యాలు మరియు అనుభవంతో పూర్తి చేయండి",
    "features.search.title": "అవకాశాలను కనుగొనండి",
    "features.search.description": "మీ నైపుణ్యాలు మరియు స్థానానికి సరిపోలే ఉద్యోగాలను శోధించండి",
    "features.apply.title": "దరఖాస్తు చేసుకోండి & కనెక్ట్ చేయండి",
    "features.apply.description": "ఉద్యోగాలకు దరఖాస్తు చేసుకోండి మరియు యజమానులతో నేరుగా సంబంధం పెట్టుకోండి",

    "jobs.featured": "ప్రత్యేక ఉద్యోగాలు",
    "jobs.viewall": "అన్ని ఉద్యోగాలను వీక్షించండి",
    "jobs.location": "స్థానం",
    "jobs.posted": "పోస్ట్ చేయబడింది",
    "jobs.apply": "ఇప్పుడు దరఖాస్తు చేసుకోండి",
    
    // Worker login and form translations in Telugu
    "worker.login.title": "కార్మిక నమోదు",
    "worker.login.subtitle": "మీ నైపుణ్యాలు మరియు స్థానానికి సరిపోలే ఉద్యోగాలను కనుగొనడానికి మీ ప్రొఫైల్‌ను సృష్టించండి",
    "worker.login.success": "ప్రొఫైల్ విజయవంతంగా సృష్టించబడింది!",
    
    "worker.form.name": "పూర్తి పేరు",
    "worker.form.namePlaceholder": "మీ పూర్తి పేరును నమోదు చేయండి",
    "worker.form.phone": "ఫోన్ నంబర్",
    "worker.form.phonePlaceholder": "మీ ఫోన్ నంబర్‌ను నమోదు చేయండి",
    "worker.form.email": "ఇమెయిల్ చిరునామా",
    "worker.form.emailPlaceholder": "మీ ఇమెయిల్ చిరునామాను నమోదు చేయండి",
    "worker.form.skills": "నైపుణ్యాలు",
    "worker.form.skillsPlaceholder": "ఉదా. ప్లంబింగ్, ఎలక్ట్రికల్, కార్పెంట్రీ",
    "worker.form.experience": "పని అనుభవం",
    "worker.form.experiencePlaceholder": "మీ గత పని అనుభవం, సర్టిఫికేషన్లు మరియు నైపుణ్యాలను వివరించండి",
    "worker.form.location": "స్థానం",
    "worker.form.locationPlaceholder": "మీ నగరం లేదా ప్రాంతం",
    "worker.form.workRadius": "పని రేడియస్ (కి.మీ)",
    "worker.form.acceptTerms": "నేను నియమాలు మరియు షరతులను అంగీకరిస్తున్నాను",
    "worker.form.submit": "ప్రొఫైల్ సృష్టించండి",
    "worker.form.submitting": "సృష్టిస్తోంది...",
    
    "footer.rights": "అన్ని హక్కులు రక్షించబడ్డాయి",
    "footer.privacy": "గోప్యతా విధానం",
    "footer.terms": "సేవా నియమాలు",
    "footer.contact": "మమ్మల్ని సంప్రదించండి",
  },
  kn: {
    "site.title": "ಬ್ಲೂಕಾಲರ್",
    "site.description": "ನಿಮ್ಮ ಪ್ರದೇಶದಲ್ಲಿ ಬ್ಲೂ-ಕಾಲರ್ ಉದ್ಯೋಗಗಳು ಮತ್ತು ಕಾರ್ಮಿಕರನ್ನು ಹುಡುಕಿ",
    
    "nav.home": "ಮುಖಪುಟ",
    "nav.jobs": "ಉದ್ಯೋಗಗಳು",
    "nav.workers": "ಕಾರ್ಮಿಕರು",
    "nav.how-it-works": "ಇದು ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ",
    "nav.login": "ಲಾಗಿನ್",
    "nav.register": "ನೋಂದಾಯಿಸಿ",
    
    "hero.title": "ಸರಿಯಾದ ಉದ್ಯೋಗ ಅಥವಾ ಸರಿಯಾದ ಕಾರ್ಮಿಕರನ್ನು ಹುಡುಕಿ",
    "hero.subtitle": "ಕೌಶಲ್ಯಪೂರ್ಣ ಬ್ಲೂ-ಕಾಲರ್ ಕಾರ್ಮಿಕರನ್ನು ಪ್ರತಿಭೆಯನ್ನು ಹುಡುಕುತ್ತಿರುವ ಉದ್ಯೋಗದಾತರೊಂದಿಗೆ ಸಂಪರ್ಕಿಸುವುದು",
    "hero.cta": "ಪ್ರಾರಂಭಿಸಿ",
    "hero.cta.workers": "ನಾನು ಕೆಲಸ ಹುಡುಕುತ್ತಿದ್ದೇನೆ",
    "hero.cta.employers": "ನನಗೆ ನೇಮಕ ಮಾಡಬೇಕಾಗಿದೆ",

    "features.title": "ಇದು ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ",
    "features.register.title": "ಪ್ರೊಫೈಲ್ ರಚಿಸಿ",
    "features.register.description": "ಸೈನ್ ಅಪ್ ಮಾಡಿ ಮತ್ತು ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಅನ್ನು ಕೌಶಲ್ಯಗಳು ಮತ್ತು ಅನುಭವದೊಂದಿಗೆ ಪೂರ್ಣಗೊಳಿಸಿ",
    "features.search.title": "ಅವಕಾಶಗಳನ್ನು ಹುಡುಕಿ",
    "features.search.description": "ನಿಮ್ಮ ಕೌಶಲ್ಯಗಳು ಮತ್ತು ಸ್ಥಳಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಉದ್ಯೋಗಗಳನ್ನು ಹುಡುಕಿ",
    "features.apply.title": "ಅಪ್ಲೈ ಮಾಡಿ & ಸಂಪರ್ಕಿಸಿ",
    "features.apply.description": "ಉದ್ಯೋಗಗಳಿಗೆ ಅರ್ಜಿ ಸಲ್ಲಿಸಿ ಮತ್ತು ಉದ್ಯೋಗದಾತರೊಂದಿಗೆ ನೇರವಾಗಿ ಸಂಪರ್ಕಿಸಿ",

    "jobs.featured": "ವಿಶೇಷ ಉದ್ಯೋಗಗಳು",
    "jobs.viewall": "ಎಲ್ಲಾ ಉದ್ಯೋಗಗಳನ್ನು ವೀಕ್ಷಿಸಿ",
    "jobs.location": "ಸ್ಥಳ",
    "jobs.posted": "ಪೋಸ್ಟ್ ಮಾಡಲಾಗಿದೆ",
    "jobs.apply": "ಈಗ ಅಪ್ಲೈ ಮಾಡಿ",
    
    // Worker login and form translations in Kannada
    "worker.login.title": "ಕಾರ್ಮಿಕ ನೋಂದಣಿ",
    "worker.login.subtitle": "ನಿಮ್ಮ ಕೌಶಲ್ಯಗಳು ಮತ್ತು ಸ್ಥಳಕ್ಕೆ ಹೊಂದಿಕೆಯಾಗುವ ಉದ್ಯೋಗಗಳನ್ನು ಹುಡುಕಲು ನಿಮ್ಮ ಪ್ರೊಫೈಲ್ ಅನ್ನು ರಚಿಸಿ",
    "worker.login.success": "ಪ್ರೊಫೈಲ್ ಯಶಸ್ವಿಯಾಗಿ ರಚಿಸಲಾಗಿದೆ!",
    
    "worker.form.name": "ಪೂರ್ಣ ಹೆಸರು",
    "worker.form.namePlaceholder": "ನಿಮ್ಮ ಪೂರ್ಣ ಹೆಸರನ್ನು ನಮೂದಿಸಿ",
    "worker.form.phone": "ಫೋನ್ ಸಂಖ್ಯೆ",
    "worker.form.phonePlaceholder": "ನಿಮ್ಮ ಫೋನ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ",
    "worker.form.email": "ಇಮೇಲ್ ವಿಳಾಸ",
    "worker.form.emailPlaceholder": "ನಿಮ್ಮ ಇಮೇಲ್ ವಿಳಾಸವನ್ನು ನಮೂದಿಸಿ",
    "worker.form.skills": "ಕೌಶಲ್ಯಗಳು",
    "worker.form.skillsPlaceholder": "ಉದಾ. ಪ್ಲಂಬಿಂಗ್, ವಿದ್ಯುತ್, ಬಡಗಿ",
    "worker.form.experience": "ಕೆಲಸದ ಅನುಭವ",
    "worker.form.experiencePlaceholder": "ನಿಮ್ಮ ಹಿಂದಿನ ಕೆಲಸದ ಅನುಭವ, ಪ್ರಮಾಣಪತ್ರಗಳು ಮತ್ತು ಕೌಶಲ್ಯಗಳನ್ನು ವಿವರಿಸಿ",
    "worker.form.location": "ಸ್ಥಳ",
    "worker.form.locationPlaceholder": "ನಿಮ್ಮ ನಗರ ಅಥವಾ ಪ್ರದೇಶ",
    "worker.form.workRadius": "ಕೆಲಸದ ತ್ರಿಜ್ಯ (ಕಿ.ಮೀ)",
    "worker.form.acceptTerms": "ನಾನು ನಿಯಮಗಳು ಮತ್ತು ಷರತ್ತುಗಳನ್ನು ಒಪ್ಪುತ್ತೇನೆ",
    "worker.form.submit": "ಪ್ರೊಫೈಲ್ ರಚಿಸಿ",
    "worker.form.submitting": "ರಚಿಸಲಾಗುತ್ತಿದೆ...",
    
    "footer.rights": "ಎಲ್ಲಾ ಹಕ್ಕುಗಳನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ",
    "footer.privacy": "ಗೌಪ್ಯತೆ ನೀತಿ",
    "footer.terms": "ಸೇವಾ ನಿಯಮಗಳು",
    "footer.contact": "ನಮ್ಮನ್ನು ಸಂಪರ್ಕಿಸಿ",
  },
};

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: () => "",
});

interface LanguageProviderProps {
  children: ReactNode;
  defaultLanguage?: Language;
}

export const LanguageProvider = ({ children, defaultLanguage = "en" }: LanguageProviderProps) => {
  const [language, setLanguage] = useState<Language>(defaultLanguage);

  const t = (key: string): string => {
    if (translations[language] && translations[language][key]) {
      return translations[language][key];
    }
    
    // Fallback to English
    if (translations["en"] && translations["en"][key]) {
      return translations["en"][key];
    }
    
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};
