
import { useLanguage } from "./LanguageProvider";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Clock, Calendar, ArrowRight } from "lucide-react";

// Mock data for featured jobs
const featuredJobs = [
  {
    id: 1,
    title: "Construction Worker",
    company: "Build Right Construction",
    location: "New York, NY",
    type: "Full-time",
    urgent: true,
    postedAt: "2 days ago",
    description: "Experienced construction worker needed for commercial building project",
    salary: "$25-$30/hour",
    startDate: "Immediate",
  },
  {
    id: 2,
    title: "Electrician",
    company: "Spark Electric Co.",
    location: "Chicago, IL",
    type: "Contract",
    urgent: false,
    postedAt: "1 week ago",
    description: "Licensed electrician for residential and commercial projects",
    salary: "$35-$45/hour",
    startDate: "June 1st",
  },
  {
    id: 3,
    title: "Plumber",
    company: "City Plumbing Services",
    location: "Houston, TX",
    type: "Part-time",
    urgent: true,
    postedAt: "3 days ago",
    description: "Experienced plumber for maintenance and repair jobs",
    salary: "$30-$40/hour",
    startDate: "Immediate",
  },
];

export function FeaturedJobs() {
  const { t } = useLanguage();

  return (
    <section className="w-full py-12 md:py-16 lg:py-24">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl animate-slide-up">
              {t("jobs.featured")}
            </h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed animate-slide-up" style={{animationDelay: "0.2s"}}>
              Check out the latest job opportunities for skilled workers
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
          {featuredJobs.map((job, index) => (
            <Card 
              key={job.id} 
              className="glass-card hover:shadow-xl transition-all duration-300 hover:translate-y-[-5px] overflow-hidden"
              style={{animationDelay: `${0.1 * (index + 1)}s`, animationFillMode: "backwards"}}
            >
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-primary">{job.title}</CardTitle>
                    <CardDescription className="mt-1">{job.company}</CardDescription>
                  </div>
                  {job.urgent && (
                    <Badge variant="destructive" className="animate-pulse">Urgent</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm">{job.description}</p>
                <div className="mt-4 space-y-2">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="mr-1 h-4 w-4 text-accent" />
                    {job.location}
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="mr-1 h-4 w-4 text-accent" />
                    {job.type}
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="mr-1 h-4 w-4 text-accent" />
                    Start: {job.startDate}
                  </div>
                  <div className="mt-2 text-sm font-medium">
                    Salary: <span className="text-accent">{job.salary}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between items-center">
                <span className="text-xs text-muted-foreground">{job.postedAt}</span>
                <Button className="bg-primary hover:bg-primary/90 transition-all duration-300 hover:translate-y-[-2px] group">
                  Apply Now
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        <div className="flex justify-center mt-8 animate-slide-up" style={{animationDelay: "0.5s"}}>
          <Button variant="outline" size="lg" className="hover:bg-accent/10 hover:text-accent transition-all duration-300 hover:border-accent group">
            View All Jobs
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
          </Button>
        </div>
      </div>
    </section>
  );
}
