
import { useLanguage } from "./LanguageProvider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Briefcase, Video, MapPin } from "lucide-react";

export function HowItWorks() {
  const { t } = useLanguage();

  const steps = [
    {
      icon: <User className="h-8 w-8 text-primary" />,
      title: "Create Your Profile",
      description: "Sign up and build your worker or employer profile with all relevant details.",
    },
    {
      icon: <Video className="h-8 w-8 text-primary" />,
      title: "Add Video Resume",
      description: "Workers can record or upload a video to showcase their skills and experience.",
    },
    {
      icon: <MapPin className="h-8 w-8 text-primary" />,
      title: "Set Your Location",
      description: "Specify your working area or job location to find relevant matches nearby.",
    },
    {
      icon: <Briefcase className="h-8 w-8 text-primary" />,
      title: "Connect & Work",
      description: "Apply for jobs or hire workers, communicate, and start working together.",
    },
  ];

  return (
    <section className="w-full py-12 md:py-16 lg:py-24 bg-secondary/50 dark:bg-secondary/20">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl animate-slide-up">
              {t("section.how-it-works")}
            </h2>
            <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed animate-slide-up" style={{animationDelay: "0.2s"}}>
              Follow these simple steps to get started with our platform
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
          {steps.map((step, index) => (
            <Card 
              key={index} 
              className="glass-card hover:shadow-lg transition-all duration-300 hover:translate-y-[-5px]"
              style={{animationDelay: `${0.1 * (index + 1)}s`}}
            >
              <CardHeader className="flex items-center pb-2">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center animate-pulse">
                  {step.icon}
                </div>
                <CardTitle className="mt-4 text-xl">{step.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-muted-foreground">
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
