
import { useState } from "react";
import { useLanguage } from "@/components/LanguageProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Video, Upload } from "lucide-react";

interface VideoSkillsUploadProps {
  onUpload: (urls: string[]) => void;
  existingVideos: string[];
}

export function VideoSkillsUpload({ onUpload, existingVideos }: VideoSkillsUploadProps) {
  const { t } = useLanguage();
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useState<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    setIsUploading(true);
    
    const uploadedUrls: string[] = [];
    
    // Simulate file upload process (in a real app, you'd upload to a server or cloud storage)
    Array.from(files).forEach(file => {
      // Check if it's a video file
      if (!file.type.startsWith('video/')) {
        toast.error(t("worker.form.invalidVideoFormat"));
        setIsUploading(false);
        return;
      }
      
      // Create local URL (in a real app, this would be a remote URL)
      const url = URL.createObjectURL(file);
      uploadedUrls.push(url);
    });
    
    // Simulate upload delay
    setTimeout(() => {
      onUpload(uploadedUrls);
      setIsUploading(false);
      toast.success(t("worker.form.videoUploaded"));
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }, 1500);
  };

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="space-y-4">
      <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center hover:bg-gray-50 dark:hover:bg-gray-900/50 transition-colors cursor-pointer" onClick={triggerFileInput}>
        <div className="flex flex-col items-center justify-center space-y-3">
          <div className="bg-primary/10 p-3 rounded-full">
            <Video className="h-6 w-6 text-primary" />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-medium">{t("worker.form.dropVideoHere")}</h3>
            <p className="text-sm text-muted-foreground">
              {t("worker.form.videoSizeLimit")}
            </p>
          </div>
          <Button 
            type="button" 
            variant="outline" 
            className="mt-4" 
            disabled={isUploading}
          >
            <Upload className="h-4 w-4 mr-2" />
            {isUploading ? t("worker.form.uploading") : t("worker.form.browse")}
          </Button>
        </div>
      </div>
      
      <Input 
        ref={(el) => fileInputRef.current = el}
        type="file" 
        accept="video/*" 
        multiple
        className="hidden" 
        onChange={handleFileChange} 
      />
    </div>
  );
}
