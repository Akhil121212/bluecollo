
import { Button } from "@/components/ui/button";
import { useLanguage } from "./LanguageProvider";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Languages } from "lucide-react";

export function LanguageToggle() {
  const { language, setLanguage } = useLanguage();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="icon-button hover:animate-pulse">
          <Languages className="h-5 w-5" />
          <span className="sr-only">Change language</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40 animate-scale-in">
        <DropdownMenuItem 
          onClick={() => setLanguage("en")} 
          className={`transition-colors duration-200 ${language === "en" ? "bg-primary/10" : ""}`}
        >
          <span className="mr-2">🇺🇸</span> English
        </DropdownMenuItem>
        <DropdownMenuItem 
          onClick={() => setLanguage("es")} 
          className={`transition-colors duration-200 ${language === "es" ? "bg-primary/10" : ""}`}
        >
          <span className="mr-2">🇪🇸</span> Español
        </DropdownMenuItem>
        <DropdownMenuItem 
          onClick={() => setLanguage("hi")} 
          className={`transition-colors duration-200 ${language === "hi" ? "bg-primary/10" : ""}`}
        >
          <span className="mr-2">🇮🇳</span> हिंदी
        </DropdownMenuItem>
        <DropdownMenuItem 
          onClick={() => setLanguage("te")} 
          className={`transition-colors duration-200 ${language === "te" ? "bg-primary/10" : ""}`}
        >
          <span className="mr-2">🇮🇳</span> తెలుగు
        </DropdownMenuItem>
        <DropdownMenuItem 
          onClick={() => setLanguage("kn")} 
          className={`transition-colors duration-200 ${language === "kn" ? "bg-primary/10" : ""}`}
        >
          <span className="mr-2">🇮🇳</span> ಕನ್ನಡ
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
