
import { useLanguage } from "./LanguageProvider";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export function Hero() {
  const { t } = useLanguage();

  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-700 via-blue-600 to-blue-500">
      <div className="container px-4 md:px-6">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="flex flex-col justify-center space-y-4 text-white">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl animate-fade-in">
                {t("hero.title")}
              </h1>
              <p className="max-w-[600px] text-gray-200 md:text-xl animate-slide-in opacity-0" style={{animationDelay: "0.2s", animationFillMode: "forwards"}}>
                {t("hero.subtitle")}
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 animate-slide-in opacity-0" style={{animationDelay: "0.4s", animationFillMode: "forwards"}}>
              <Button className="bg-accent hover:bg-accent/90 text-white transition-all duration-300 hover:translate-y-[-2px]" size="lg">
                {t("hero.cta.workers")}
                <ArrowRight className="ml-2 h-4 w-4 animate-bounce" />
              </Button>
              <Button variant="outline" className="border-white text-white hover:bg-white/20 transition-all duration-300 hover:translate-y-[-2px]" size="lg">
                {t("hero.cta.employers")}
              </Button>
            </div>
          </div>
          <div className="mx-auto w-full max-w-[500px] animate-fade-in hover-scale hover-shadow">
            <div className="aspect-video overflow-hidden rounded-xl border shadow-xl transform transition-all duration-500 hover:scale-[1.02]">
              <img
                alt="Workers collaborating on construction site"
                className="object-cover w-full h-full transition-transform duration-700 hover:scale-105"
                src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?q=80&w=2070&auto=format&fit=crop"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
