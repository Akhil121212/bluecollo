
import { useState, useRef, useEffect } from "react";
import { useLanguage } from "@/components/LanguageProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { MessageCircle, Send, Mic, MicOff, Languages, Translate } from "lucide-react";

interface Message {
  id: string;
  sender: 'worker' | 'manager';
  text: string;
  timestamp: Date;
  translated?: string;
}

const supportedLanguages = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'hi', name: 'Hindi' },
  { code: 'te', name: 'Telugu' },
  { code: 'kn', name: 'Kannada' },
];

export function DirectChat() {
  const { t, language, setLanguage } = useLanguage();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'manager',
      text: 'Hello! Welcome to our team. How can I help you today?',
      timestamp: new Date(Date.now() - 3600000),
    },
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [translationLanguage, setTranslationLanguage] = useState(language);
  const [autoTranslate, setAutoTranslate] = useState(true);
  const [isRecording, setIsRecording] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    const workerMessage: Message = {
      id: Date.now().toString(),
      sender: 'worker',
      text: newMessage,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, workerMessage]);
    setNewMessage('');
    
    // Focus the textarea again after sending
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
    
    // Simulate manager response after delay
    setTimeout(() => {
      const managerMessage: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'manager',
        text: getSimulatedResponse(newMessage),
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, managerMessage]);
      
      // If auto-translate is on, translate the manager's message
      if (autoTranslate) {
        setTimeout(() => {
          translateMessage(managerMessage.id);
        }, 500);
      }
    }, 2000);
  };

  // Simulate speech recognition
  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      // Simulate speech recognition result
      const recognizedText = "This is a simulated speech recognition result.";
      setNewMessage(prev => prev + " " + recognizedText);
      toast.success(t("chat.speechRecognized"));
    } else {
      setIsRecording(true);
      toast.info(t("chat.recording"));
      // Simulate recording for 3 seconds
      setTimeout(() => {
        if (isRecording) toggleRecording();
      }, 3000);
    }
  };

  // Simulated translation function
  const translateMessage = (messageId: string) => {
    setMessages(prev => 
      prev.map(msg => {
        if (msg.id === messageId) {
          // Simulate translation based on selected language
          const translatedText = simulateTranslation(msg.text, translationLanguage);
          return { ...msg, translated: translatedText };
        }
        return msg;
      })
    );
    
    toast.success(t("chat.translated"));
  };
  
  // Simulate a basic response
  const getSimulatedResponse = (message: string) => {
    const responses = [
      "Thank you for your message. I'll look into that for you.",
      "That's a good point. Let me check with the team and get back to you.",
      "I understand your concern. We'll work on resolving this soon.",
      "Great progress! Keep up the good work.",
      "Could you provide more details about this issue?",
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };
  
  // Simulate translation
  const simulateTranslation = (text: string, targetLang: string) => {
    const translations: Record<string, Record<string, string>> = {
      'en': {
        'Hello! Welcome to our team. How can I help you today?': 'Hello! Welcome to our team. How can I help you today?',
        'Thank you for your message. I\'ll look into that for you.': 'Thank you for your message. I\'ll look into that for you.',
        'That\'s a good point. Let me check with the team and get back to you.': 'That\'s a good point. Let me check with the team and get back to you.',
        'I understand your concern. We\'ll work on resolving this soon.': 'I understand your concern. We\'ll work on resolving this soon.',
        'Great progress! Keep up the good work.': 'Great progress! Keep up the good work.',
        'Could you provide more details about this issue?': 'Could you provide more details about this issue?',
      },
      'es': {
        'Hello! Welcome to our team. How can I help you today?': '¡Hola! Bienvenido a nuestro equipo. ¿Cómo puedo ayudarte hoy?',
        'Thank you for your message. I\'ll look into that for you.': 'Gracias por tu mensaje. Investigaré eso para ti.',
        'That\'s a good point. Let me check with the team and get back to you.': 'Es un buen punto. Déjame verificar con el equipo y te responderé.',
        'I understand your concern. We\'ll work on resolving this soon.': 'Entiendo tu preocupación. Trabajaremos para resolverlo pronto.',
        'Great progress! Keep up the good work.': '¡Gran progreso! Sigue con el buen trabajo.',
        'Could you provide more details about this issue?': '¿Podrías proporcionar más detalles sobre este problema?',
      },
      'hi': {
        'Hello! Welcome to our team. How can I help you today?': 'नमस्ते! हमारी टीम में आपका स्वागत है। आज मैं आपकी कैसे मदद कर सकता हूं?',
        'Thank you for your message. I\'ll look into that for you.': 'आपके संदेश के लिए धन्यवाद। मैं आपके लिए इसकी जांच करूंगा।',
        'That\'s a good point. Let me check with the team and get back to you.': 'यह एक अच्छा बिंदु है। मुझे टीम के साथ जांच करने दें और मैं आपको वापस बताऊंगा।',
        'I understand your concern. We\'ll work on resolving this soon.': 'मैं आपकी चिंता समझता हूं। हम इसे जल्द ही हल करने पर काम करेंगे।',
        'Great progress! Keep up the good work.': 'बढ़िया प्रगति! अच्छा काम जारी रखें।',
        'Could you provide more details about this issue?': 'क्या आप इस समस्या के बारे में अधिक जानकारी दे सकते हैं?',
      },
    };
    
    // If we have a translation for this text and language
    if (translations[targetLang]?.[text]) {
      return translations[targetLang][text];
    }
    
    // Fallback: modify the text slightly to simulate translation
    return `[${supportedLanguages.find(lang => lang.code === targetLang)?.name}] ${text}`;
  };

  return (
    <div className="flex flex-col h-full border rounded-lg overflow-hidden">
      <div className="bg-primary/10 p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-primary" />
          <h2 className="font-medium">{t("chat.title")}</h2>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            className={`${autoTranslate ? 'bg-primary/20' : ''}`}
            onClick={() => setAutoTranslate(!autoTranslate)}
            title={t("chat.toggleAutoTranslate")}
          >
            <Translate className="h-4 w-4" />
          </Button>
          <Select value={translationLanguage} onValueChange={setTranslationLanguage}>
            <SelectTrigger className="w-[130px] h-8">
              <SelectValue placeholder={t("chat.selectLanguage")} />
            </SelectTrigger>
            <SelectContent>
              {supportedLanguages.map(lang => (
                <SelectItem key={lang.code} value={lang.code}>
                  {lang.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <ScrollArea className="flex-grow p-4 h-[400px]">
        <div className="space-y-4">
          {messages.map(message => (
            <div 
              key={message.id} 
              className={`flex ${message.sender === 'worker' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.sender === 'worker' 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-muted'
                }`}
              >
                <div className="text-sm">{message.text}</div>
                {message.translated && (
                  <div className="mt-2 pt-2 border-t border-white/20 text-sm opacity-80 flex items-center gap-1">
                    <Languages className="h-3 w-3" />
                    {message.translated}
                  </div>
                )}
                <div className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
      
      <form onSubmit={handleSubmit} className="p-4 border-t">
        <div className="flex gap-2">
          <Textarea
            ref={textareaRef}
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder={t("chat.typingPlaceholder")}
            className="min-h-10 flex-grow"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <div className="flex flex-col gap-2">
            <Button 
              type="button" 
              size="icon" 
              variant={isRecording ? "destructive" : "outline"}
              onClick={toggleRecording}
            >
              {isRecording ? (
                <MicOff className="h-4 w-4" />
              ) : (
                <Mic className="h-4 w-4" />
              )}
            </Button>
            <Button type="submit" size="icon" className="aspect-square">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
