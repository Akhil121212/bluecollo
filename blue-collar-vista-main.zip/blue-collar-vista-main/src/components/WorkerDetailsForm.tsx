
import { useState } from "react";
import { useLanguage } from "@/components/LanguageProvider";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { VideoSkillsUpload } from "@/components/VideoSkillsUpload";
import { Video, Upload, User } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const formSchema = z.object({
  name: z.string().min(2, {
    message: "Name must be at least 2 characters.",
  }),
  phone: z.string().min(10, {
    message: "Phone number must be at least 10 digits.",
  }),
  email: z.string().email({
    message: "Please enter a valid email.",
  }),
  skills: z.string().min(3, {
    message: "Please list at least one skill.",
  }),
  experience: z.string().min(3, {
    message: "Please provide your experience details.",
  }),
  location: z.string().min(3, {
    message: "Please enter your location.",
  }),
  workRadius: z.string(),
  acceptTerms: z.boolean().refine(val => val === true, {
    message: "You must accept the terms and conditions",
  }),
  videoSkills: z.array(z.string()).optional(),
});

export function WorkerDetailsForm() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [videoUrls, setVideoUrls] = useState<string[]>([]);
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      skills: "",
      experience: "",
      location: "",
      workRadius: "25",
      acceptTerms: false,
      videoSkills: [],
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    
    // Add video URLs to form data
    values.videoSkills = videoUrls;
    
    // Simulate API call
    setTimeout(() => {
      console.log(values);
      toast.success(t("worker.login.success"));
      setIsLoading(false);
      navigate("/dashboard");
    }, 1500);
  }

  const handleVideoUpload = (urls: string[]) => {
    setVideoUrls(prev => [...prev, ...urls]);
    form.setValue('videoSkills', [...videoUrls, ...urls]);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 space-y-6">
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="basic" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              {t("worker.form.basicInfo")}
            </TabsTrigger>
            <TabsTrigger value="video" className="flex items-center gap-2">
              <Video className="h-4 w-4" />
              {t("worker.form.videoSkills")}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="basic" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem className="animate-slide-up" style={{ animationDelay: "100ms" }}>
                    <FormLabel>{t("worker.form.name")}</FormLabel>
                    <FormControl>
                      <Input className="hover-scale" placeholder={t("worker.form.namePlaceholder")} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem className="animate-slide-up" style={{ animationDelay: "200ms" }}>
                    <FormLabel>{t("worker.form.phone")}</FormLabel>
                    <FormControl>
                      <Input className="hover-scale" type="tel" placeholder={t("worker.form.phonePlaceholder")} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="animate-slide-up" style={{ animationDelay: "300ms" }}>
                    <FormLabel>{t("worker.form.email")}</FormLabel>
                    <FormControl>
                      <Input className="hover-scale" type="email" placeholder={t("worker.form.emailPlaceholder")} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="skills"
                render={({ field }) => (
                  <FormItem className="animate-slide-up" style={{ animationDelay: "400ms" }}>
                    <FormLabel>{t("worker.form.skills")}</FormLabel>
                    <FormControl>
                      <Input className="hover-scale" placeholder={t("worker.form.skillsPlaceholder")} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="experience"
                render={({ field }) => (
                  <FormItem className="md:col-span-2 animate-slide-up" style={{ animationDelay: "500ms" }}>
                    <FormLabel>{t("worker.form.experience")}</FormLabel>
                    <FormControl>
                      <Textarea 
                        className="hover-scale min-h-24" 
                        placeholder={t("worker.form.experiencePlaceholder")} 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem className="animate-slide-up" style={{ animationDelay: "600ms" }}>
                    <FormLabel>{t("worker.form.location")}</FormLabel>
                    <FormControl>
                      <Input className="hover-scale" placeholder={t("worker.form.locationPlaceholder")} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="workRadius"
                render={({ field }) => (
                  <FormItem className="animate-slide-up" style={{ animationDelay: "700ms" }}>
                    <FormLabel>{t("worker.form.workRadius")}</FormLabel>
                    <FormControl>
                      <div className="flex items-center gap-2">
                        <Input 
                          className="hover-scale" 
                          type="number" 
                          min="1" 
                          max="200" 
                          {...field} 
                        />
                        <span className="text-sm text-muted-foreground">km</span>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="acceptTerms"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 animate-slide-up" style={{ animationDelay: "800ms" }}>
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-sm font-normal">
                      {t("worker.form.acceptTerms")}
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />
          </TabsContent>
          
          <TabsContent value="video" className="space-y-6">
            <div className="animate-slide-up" style={{ animationDelay: "100ms" }}>
              <h3 className="text-lg font-medium mb-4">{t("worker.form.uploadVideoTitle")}</h3>
              <p className="text-sm text-muted-foreground mb-6">
                {t("worker.form.uploadVideoDescription")}
              </p>
              
              <VideoSkillsUpload onUpload={handleVideoUpload} existingVideos={videoUrls} />
              
              <div className="mt-6">
                {videoUrls.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium">{t("worker.form.uploadedVideos")}</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {videoUrls.map((url, idx) => (
                        <div key={idx} className="relative rounded-md overflow-hidden border">
                          <video 
                            src={url} 
                            controls 
                            className="w-full h-40 object-cover"
                          />
                          <Button 
                            variant="destructive" 
                            size="sm" 
                            className="absolute top-2 right-2"
                            onClick={() => {
                              const newUrls = videoUrls.filter((_, i) => i !== idx);
                              setVideoUrls(newUrls);
                              form.setValue('videoSkills', newUrls);
                            }}
                          >
                            {t("worker.form.remove")}
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center pt-4 animate-slide-up" style={{ animationDelay: "900ms" }}>
          <Button type="submit" disabled={isLoading} className="w-full md:w-auto min-w-40 hover-scale">
            {isLoading ? t("worker.form.submitting") : t("worker.form.submit")}
          </Button>
        </div>
      </form>
    </Form>
  );
}
