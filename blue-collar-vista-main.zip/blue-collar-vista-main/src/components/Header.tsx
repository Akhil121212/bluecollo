
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./ThemeToggle";
import { LanguageToggle } from "./LanguageToggle";
import { useLanguage } from "./LanguageProvider";
import { Link } from "react-router-dom";
import { Home, Briefcase, User, Menu, X } from "lucide-react";

export function Header() {
  const { t } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center gap-2 text-xl font-bold text-primary">
            <Briefcase className="h-6 w-6" />
            {t("site.title")}
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-foreground/80 hover:text-foreground transition-colors">
            <span className="flex items-center gap-1">
              <Home className="h-4 w-4" />
              {t("nav.home")}
            </span>
          </Link>
          <Link to="/jobs" className="text-foreground/80 hover:text-foreground transition-colors">
            <span className="flex items-center gap-1">
              <Briefcase className="h-4 w-4" />
              {t("nav.jobs")}
            </span>
          </Link>
          <Link to="/workers" className="text-foreground/80 hover:text-foreground transition-colors">
            <span className="flex items-center gap-1">
              <User className="h-4 w-4" />
              {t("nav.workers")}
            </span>
          </Link>
          <Link to="/how-it-works" className="text-foreground/80 hover:text-foreground transition-colors">
            {t("nav.how-it-works")}
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <div className="hidden md:flex items-center gap-2">
            <Button variant="ghost" asChild>
              <Link to="/worker-login">{t("nav.login")}</Link>
            </Button>
            <Button variant="default" asChild>
              <Link to="/worker-login">{t("nav.register")}</Link>
            </Button>
          </div>
          <ThemeToggle />
          <LanguageToggle />
          <Button variant="ghost" size="icon" className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container py-4 flex flex-col gap-4">
            <Link to="/" className="flex items-center gap-2 py-2">
              <Home className="h-5 w-5" />
              {t("nav.home")}
            </Link>
            <Link to="/jobs" className="flex items-center gap-2 py-2">
              <Briefcase className="h-5 w-5" />
              {t("nav.jobs")}
            </Link>
            <Link to="/workers" className="flex items-center gap-2 py-2">
              <User className="h-5 w-5" />
              {t("nav.workers")}
            </Link>
            <Link to="/how-it-works" className="py-2">
              {t("nav.how-it-works")}
            </Link>
            <div className="flex gap-2 mt-2">
              <Button variant="outline" className="flex-1" asChild>
                <Link to="/worker-login">{t("nav.login")}</Link>
              </Button>
              <Button variant="default" className="flex-1" asChild>
                <Link to="/worker-login">{t("nav.register")}</Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
